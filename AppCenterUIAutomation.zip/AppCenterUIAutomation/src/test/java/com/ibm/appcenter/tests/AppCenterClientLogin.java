package com.ibm.appcenter.tests;		

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ibm.appcenter.tests.utils.ServerUtil;

import io.appium.java_client.ios.IOSDriver;	

public class AppCenterClientLogin {		
		
		public WebDriver driver;
	    public ServerUtil serverutil;
	    public WebDriverWait wait;
	
	    @BeforeClass
		public void setup() throws MalformedURLException {
	    	serverutil = ServerUtil.getInstance();
	    	DesiredCapabilities capabilities = new DesiredCapabilities();
			capabilities.setCapability("appium-version", "1.0");
			capabilities.setCapability("platformName", "iOS");
			capabilities.setCapability("platformVersion", "9.3");
			capabilities.setCapability("deviceName", "iPhone 6");
			//*********Change this to point to your path*********//
			capabilities.setCapability("app", serverutil.getAppCenterClientPath());
			driver = new IOSDriver<WebElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
			wait = new WebDriverWait(driver, 15);
		}
		
		@AfterClass
		public void teardown() {
			driver.quit();	
		}
		
	    @Test				
		public void loginMobileClientAppCenter() {	
			
	    	//*********Enter the login details and login*********//
			WebElement userField = driver.findElement(By.xpath("//UIATextField[@value='User name']"));
			userField.click();
			userField.sendKeys(serverutil.getUsername());
			
			WebElement passwordField = driver.findElement(By.xpath("//UIASecureTextField[@value='Password']"));
			passwordField.click();
			passwordField.sendKeys(serverutil.getPassword());
			
			WebElement hostField = driver.findElement(By.xpath("//UIATextField[@value='Host name or IP']"));
			hostField.click();
			hostField.sendKeys(serverutil.getHost());
			
			WebElement portField = driver.findElement(By.xpath("//UIATextField[@value='Server port']"));
			portField.click();
			portField.sendKeys(""+ serverutil.getPort() + "");
			
			WebElement contextField = driver.findElement(By.xpath("//UIATextField[@value='Application context']"));
			contextField.click();
			contextField.sendKeys(serverutil.getMobContext());
			
			driver.findElement(By.xpath("//UIAWebView[1]/UIAButton[1]")).click();			
			WebElement alertElement =
				    new WebDriverWait(driver, 15).until(
				    ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAAlert[1]")));
			
			//*********If notification is enabled you will get the popup*********//
			if (alertElement.isDisplayed()) {	
				driver.switchTo().alert().accept();
			}
			
			//*********Catalog: Displaying the apps*********//
			WebElement catalogElement = wait.until(
				    ExpectedConditions.presenceOfElementLocated(By.xpath("//UIAStaticText[1]")));
			if (catalogElement.isDisplayed()) {
				AssertJUnit.assertEquals("Catalog", catalogElement.getText());
			} else {
				AssertJUnit.assertEquals(1, 0);//fail the case
			}
		}
}